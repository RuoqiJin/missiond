;; ══════════════════════════════════════════════════════
;; MissionD — Memory Pillar Execution Log (施工并行 agent 共享内存层)
;; Parent:   .missiond/v2/intent-memory.lisp :: v0.4.23 frozen @ commit a282f87
;; Created:  2026-04-20
;; Purpose:  memory pillar 代码同构施工过程记录 — 6 slots (agent-execution-coordination 模式)
;;
;; 读写规则 (和 board :: helper agent-execution-coordination 一致):
;;   phase-tracker:  当前 phase 全局状态
;;   claims:         谁锁定了哪个 scope (防并发写冲突)
;;   deviations:     意图 (frozen lisp) 与实际 (code) 的差异 — 格式 D<NNN>
;;   decisions:      决策日志 — 格式 DC<NNN>
;;   completions:    phase 完成清单 — 断点续跑基础
;;   issues:         阻塞/未决问题 — 格式 I<NNN>
;;
;; ID 分配: 每个 agent 写前 claim 下一个未用 ID (串行化通过主 Claude 或 file lock)
;; frozen lisp 改动: 必须先记 deviation D<NNN>, 指挥官批准后才改 frozen lisp
;; ══════════════════════════════════════════════════════

(execution memory-pillar-isomorphism
  (parent-lisp "intent-memory.lisp :: v0.4.23 (commit a282f87)")
  (pairing-with "frozen design lisp ↔ execution log (pilot: intent-event-bus.lisp ↔ intent-event-bus-execution.lisp)")
  (created "2026-04-20")
  (scope "memory pillar 代码同构 — target-code-layout :: in-scope 5 路径")

  ;; ─────────────────────────────────────────────────────────
  ;; phase-tracker — 当前施工全局状态
  ;; ─────────────────────────────────────────────────────────
  (phase-tracker
    :current-phase "phase-2-stage-2A.1"
    :started-at "2026-04-20"
    :strategy "指挥官选 A: 稳扎稳打分批. 老代码耦合严重, lisp 新架构优雅. 稳不出错就是快. 派 agent-team 保护主会话 context"
    :roadmap
      (phase-1 :name "file-to-module-mapping 扫描补齐"     :status "completed"   :delivered "comp-001 + comp-002 + comp-003; D001/D002/I001-I007 全部闭环")
      (phase-2 :name "代码向 lisp 对齐 (6 stage 分批)"      :status "in-progress"
        :stages-order "2A 热身 → 2B 新建 trait 壳 → 2C 合并子 trait → 2D 跨 trait 拆分 → 2E sqlite 生态清理 → 2F wild files 补分类"
        (stage-2A "轻量独立动作 (热身)"
          (2A.1 "删除两套 gen_*.rs (16 文件 8302 LOC ~285KB, 未被 mod.rs 导入)" :status "completed" :at "2026-04-20" :cargo-build "通过")
          (2A.2 "kb-manager: KnowledgeStore → KbStore rename"                    :status "completed" :at "2026-04-20" :cargo-build "通过")
          (2A.3 "TimelineStore 归属重审 + 删 db/timeline.rs 空壳"
            :status "completed"
            :correction "**原前提错** — Stage 2A.3 原说 'TimelineStore deprecated 应删'. 调研发现 TimelineStore 是 pillar 四 event-bus 的 projection 读接口 (见 intent-event-bus-execution.lisp L170), 不是 memory pillar 的 trait"
            :actually-done "(a) 保留 TimelineStore trait 原样 (归 pillar 四 所有); (b) 删 db/timeline.rs (551B 冗余空壳 — re-export 已由 db/mod.rs:61 shared:: 替代); (c) mod.rs 删掉 sqlite-gated 'pub(crate) mod timeline;' 一行"
            :deviation-from-plan "D003"
            :at "2026-04-20" :cargo-build "通过")
          (2A.4 "I001 wild files 文档分类 → stage-2F (主会话批量补执行 lisp)"    :status "moved-to-2F"))
        (stage-2B "新建 trait 壳 — InfraStore + DirectiveLayerStore 空壳先建"  :status "in-progress"
          (2B.1 "新建 InfraStore trait 空壳 (方法 Stage 2D 填)"  :status "completed"
            :location "traits.rs:719-730 + MissionStore bound :762 + pg/infra.rs 新建 + sqlite/mod.rs:68-71"
            :rust-analyzer-note "rust-analyzer 报 E0277 trait has no implementations, 但 cargo build --workspace 通过 — 是 IDE feature-detection 缓存问题, 不阻断施工"
            :at "2026-04-20")
          (2B.2 "新建 DirectiveLayerStore (trait + 3 文件 + 17 方法 PG impl)"
            :status "completed"
            :files-created ["types/directive.rs(189L)" "db/directive.rs(23L)" "pg/directive.rs(372L)"]
            :cargo-build "workspace 通过"
            :side-effect "Cargo.toml 加 'serde' 到 uuid features (DTO 需 Serialize)"
            :at "2026-04-20"))
        (stage-2C "合并子 trait (SkillStore / ToolCall / Event / Retrospective / Vision)" :status "in-progress"
          (2C.1 "SkillStore → ProjectStore (25+8=33 方法) + 补建 db/project.rs" :status "completed" :at "2026-04-20" :cargo "通过")
          (2C.2 "ToolCallStore → ConversationStore (19 方法)" :status "completed" :at "2026-04-20")
          (2C.3 "EventStore → ConversationStore (7 方法)" :status "completed" :at "2026-04-20")
          (2C.4 "RetrospectiveStore → ConversationStore (15 方法)" :status "completed" :at "2026-04-20")
          (2C.5 "VisionStore → ObservabilityStore (10 方法实测) + 补建 db/observability.rs"
            :status "completed" :at "2026-04-20"
            :note "agent 实测 10 方法非预期 8 (7 image + 3 translation). ObservabilityStore 最终 80 方法"))
        (stage-2D "跨 trait 拆分 (watermarks/backfill/daemon_state → InfraStore)" :status "completed" :at "2026-04-20"
          :migration-stats "InfraStore 0→24 方法, ObservabilityStore 80→58 (-22), SlotStore 40→38 (-2)"
          :files "pg/infra.rs 14→386L, pg/observability.rs -335L, pg/slot.rs -26L")
        (stage-2E "清理 sqlite 生态 (一次性大扫除)" :status "completed" :at "2026-04-20"
          :deleted "sqlite/ 整目录 10 文件 + db/ 下 21 个 sqlite-gated 文件 (含 migration.rs 1675L) = 31 文件 ~14018 LOC ~360KB"
          :migrate-tool-kept "pg/migrate_from_sqlite.rs 保留, feature-gated 'all(sqlite, postgres)' 当前永不编译, 加 DEPRECATED doc"
          :src-rewrites "inbox.rs/slot_manager.rs/mission_control.rs/learned_permissions.rs/main.rs 去 sqlite 分支; types/board.rs 去 rusqlite impl; db/error.rs 去 DbError::Sqlite 变体"
          :cargo-toml "core 删 sqlite feature + rusqlite; daemon 删 sqlite feature (codex 仍 rusqlite)"
          :db-mod-rs "422→58 行 (压缩 86%)"
          :cargo-build "--workspace 0 error; --tests --no-run 0 error")
        (stage-2F "I001 wild files 补分类 → file-to-module-mapping-complete" :status "completed" :at "2026-04-20"
          :note "Stage 2A-2E 执行后, 大部分 wild files 自然消除 (删除 / 合并). 剩余文件每个都已归属明确, 记录在 file-to-module-mapping-complete 槽位下"))
      (phase-3 :name "(deprecated — 合并进 phase-2 stage-2B + 独立)"         :status "merged-into-phase-2")
      (phase-4 :name "binds-to cross-ref 验证" :status "completed" :at "2026-04-20"
        :result "mcp-surface 100% / trait-surface 9/9 / cross-ref 51/51 pointer 通过 / frontend-surface 5 streams 大致 OK / external-filesystem 约定 paths 引用存在")
      (phase-5 :name "lisp ↔ code 双向同构校验" :status "completed" :at "2026-04-20"
        :result "lisp→code 0 orphan (60 表 + 9 trait 全部在代码存在); code→lisp 发现 5 documentation drift (D-004 ~ D-008)")
      (phase-6 :name "drop migration + zombie cleanup" :status "completed" :at "2026-04-20"
        :scope "按 frozen lisp 实际声明保守执行 — 只 drop 4 张 (narrations 2 + events + credentials), 不 drop lisp 仍 KEEP 的 tasks + DEPRECATE 的 inbox"
        :deliverable "migration 20260421000000_drop_deprecated_tables.sql + traits 删 11 方法 + pg/ 删 ~290L zombie code + step_narrator.rs 整文件删 + 5 caller 清理")
      (v0.5.0-migration :name "memory-hook 迁 board_tasks (phased B 方案)" :status "completed" :at "2026-04-20"
        :lisp "v0.5.0 from v0.4.24, D010 修订 partial migration (非全 drop)"
        :deliverable "migration 20260421100000_add_board_tasks_trigger_source.sql + 5 memory-pillar caller 迁移 + BoardStore::list_board_tasks_by_trigger + BoardTask.trigger_source 字段"
        :untouched "tasks 表 / SlotStore 8 tasks 方法 / inbox / pillar 二 的 25 caller (mission_task_submit MCP 族等)"))

  ;; ─────────────────────────────────────────────────────────
  ;; claims — 谁锁定了什么, 防并发写冲突
  ;; ─────────────────────────────────────────────────────────
  (claims
    ;; 示例: (C001 :claimer "explore-agent-1" :scope ["crates/missiond-core/src/db/"] :phase "phase-1" :at "2026-04-20T..." :released false)
    )

  ;; ─────────────────────────────────────────────────────────
  ;; deviations — frozen lisp 意图 vs 代码实际的差异
  ;; 记录前 frozen lisp 不能改; 记录后等指挥官批准才能改
  ;; ─────────────────────────────────────────────────────────
  (deviations
    (D001
      :lisp-said "骨架 file-to-module-mapping 列 'db/project.rs → ProjectStore' 和 'db/observability.rs → ObservabilityStore'"
      :ground-truth-verified "主 Claude 用 ls 验证: db/project.rs 不存在, db/observability.rs 不存在. 仅 pg/project.rs + pg/observability.rs 存在."
      :actually-found "ProjectStore trait 定义在 db/traits.rs:724, impl 在 db/pg/project.rs (550+ 行); ObservabilityStore trait 定义在 traits.rs:614, impl 在 db/pg/observability.rs (1200+ 行). **无 db-level 中间层文件**"
      :reason "lisp 骨架假设两层 db/<name>.rs + db/pg/<name>.rs, 但这 2 处 domain 实际只有单层 (trait 在 traits.rs, impl 在 pg/)"
      :decided "指挥官指示: 代码向 lisp 对齐. 应建 db/project.rs 和 db/observability.rs 中间层文件, 承载本 domain 的 Row struct + enum + 任何非 PG-specific 的逻辑 (follow db/board.rs / db/conversation.rs 等现有 pattern)"
      :决策-方向 "(c) 施工时补建 — 先看其他 db/<name>.rs 内容模式, 按样补 db/project.rs 和 db/observability.rs"
      :施工-action "phase-2 按 module 重构时顺便建这 2 文件"
      :status "approved-decided"
      :at "2026-04-20 phase-1.5")

    (D002
      :lisp-said "pillar-interfaces :: worker-trait-surface :: current-traits 列 9 traits + cross-cutting db-trait-abstraction :stores 9"
      :ground-truth-verified "主 Claude + phase-1.5 agent 核实: traits.rs 实际 13 active trait (非 14)"
      :code-13-traits
        (ConversationStore    :行 27   :方法 56 :lisp-有 "ConversationStore")
        (MessageStore         :行 159  :方法 15 :lisp-有 "MessageStore")
        (ToolCallStore        :行 215  :方法  8 :lisp-无 "lisp 未列为 primary, 是 ConversationStore 的 sub-trait")
        (EventStore           :行 245  :方法  6 :lisp-无 "同上, conversation-logs sub-trait")
        (RetrospectiveStore   :行 261  :方法 13 :lisp-无 "同上, conversation-logs sub-trait")
        (VisionStore          :行 288  :方法  8 :lisp-无 "system-support sub-trait (image_descriptions), 应合并 ObservabilityStore")
        (KnowledgeStore       :行 308  :方法 56 :lisp-有-rename "lisp 叫 KbStore, 代码叫 KnowledgeStore — 命名不符!")
        (BoardStore           :行 396  :方法 41 :lisp-有 "BoardStore")
        (TimelineStore        :行 462  :方法  6 :lisp-无 "v0.4.20 误判为 deprecated; 实际是 pillar 四 event-bus projection 读接口 (event-bus-execution.lisp L170 声明重构为 projection delegate); 归 pillar 四, 不是 memory trait; 保留原样")
        (SlotStore            :行 478  :方法 41 :lisp-有 "SlotStore")
        (SkillStore           :行 540  :方法 25 :lisp-无 "lisp 把 skill 归 ProjectStore; 代码是独立 trait")
        (ObservabilityStore   :行 614  :方法 75 :lisp-有 "ObservabilityStore")
        (ProjectStore         :行 724  :方法  7 :lisp-有 "ProjectStore (只 7 方法; skill_* 4 表方法在 SkillStore 里)")
      :lisp-3-traits-code-没
        (KbStore              :status "rename needed — 代码叫 KnowledgeStore")
        (DirectiveLayerStore  :status "TBD — v0.4.17 声明, 未实现, phase-3 建")
        (InfraStore           :status "⚠ 代码没有! watermarks/backfill/daemon_state 方法散在 ObservabilityStore + SlotStore 里")
      :reason "lisp '9 primary traits' 是简化公开视图; 代码按 .rs 文件切粒度更细, 产生 13 active trait (含 5 个 lisp 视为 sub-trait 的 + 命名差异 1 + deprecated 1)"
      :decided "指挥官指示: 代码向 lisp 对齐. 代码重构向 9 primary traits 合并"
      :决策-方向
        (rename-KnowledgeStore→KbStore   :priority P1 :effort small)
        (delete-TimelineStore              :priority P1 :effort small :已 deprecated)
        (merge-SkillStore-into-ProjectStore :priority P2 :effort medium :lisp-说 "skill_* 4 表归 ProjectStore")
        (merge-ToolCallStore-into-ConversationStore :priority P2 :effort medium)
        (merge-EventStore-into-ConversationStore    :priority P2 :effort medium)
        (merge-RetrospectiveStore-into-ConversationStore :priority P2 :effort small)
        (merge-VisionStore-into-ObservabilityStore  :priority P2 :effort small)
        (建-InfraStore                    :priority P1 :effort medium
                                          :from "从 ObservabilityStore 拆 watermarks+backfill; 从 SlotStore 拆 daemon_state"
                                          :lisp-说 "InfraStore 归 system-support: infrastructure_state + backfill_* + daemon_state")
        (建-DirectiveLayerStore           :priority P1 :effort large "phase-3 专项, 新建 15 方法")
      :status "approved-decided"
      :at "2026-04-20 phase-1.5")

    (D004
      :source "Phase 4+5 audit (agent ab3a924be68435f5a)"
      :finding "lisp target-code-layout :: file-to-module-mapping (v0.4.22 骨架) 引用 db/board.rs / db/question.rs / db/ast.rs / db/gemini_log.rs / db/task.rs / db/backfill.rs / db/incident.rs / db/knowledge.rs / db/conversation.rs / db/slot.rs / db/observability.rs — 但 Phase 2 后这些文件全部转移到 db/pg/*.rs 或 types/*.rs, db/ 根只剩 8 文件"
      :note "lisp 已标 :status 🚧 初始骨架 pending phase-1 scan 补齐, 所以这是 known-incomplete 非真错"
      :resolved-by "execution lisp 的 file-to-module-mapping-complete 槽位 (Stage 2F 产出) 已给终极映射"
      :status "tracked-resolved" :at "2026-04-20")

    (D005
      :source "Phase 4+5 audit"
      :finding "db/conversation_query.rs 文件存在但未在 lisp file-to-module-mapping 骨架里列"
      :note "execution lisp file-to-module-mapping-complete 已补"
      :status "tracked-resolved")

    (D006
      :source "Phase 4+5 audit"
      :finding "workers/codex/step_narrator.rs + workers/local/xjpcode_briefing_worker.rs 文件还在, lisp 多处说 worker-removed. 属 pillar 二 (out-of-scope for memory pillar), 但 memory lisp v0.4.12 history 的声明与实际有 drift"
      :action "记为 I-series 给 pillar 二 施工时清理; memory pillar 同构不动这些文件"
      :status "tracked-out-of-scope")

    (D007
      :source "Phase 4+5 audit"
      :finding "ConversationStore::insert_narrations + message_narrations / narration_cursors 表仍活着. lisp v0.4.12 说'narrations 下线'但 migration + trait 未执行"
      :action "Phase 6 drop migration 处理 — 选择: (a) 真 drop (按 lisp) 或 (b) lisp 后续版本 rephrase '写 paused, schema 保留'"
      :decision "按指挥官 '代码向 lisp 对齐' 原则, Phase 6 真 drop"
      :status "phase-6-target")

    (D008
      :source "Phase 4+5 audit"
      :finding "types/async_job.rs / types/dynamic_slot.rs / types/gen_types.rs 不在 lisp file-to-module-mapping"
      :status "tracked-minor")

    (D010
      :source "v0.5.0 设计执行 agent (a6e8e73cafad2d6e5) 调研后 stop"
      :lisp-said "v0.5.0 设计: tasks 表 ✅ DROPPED, 所有 30+ caller 迁 board_tasks"
      :actually-found "tasks 表实际 30+ caller 里 25 个在 pillar 二: handlers/compute/task.rs (mission_task_submit MCP 族 500+L) / supervisor.rs (slot 死亡恢复) / handlers/compute/pty.rs / context/context_pipeline.rs / engine/learning_engine/extraction.rs"
      :memory-pillar-only "仅 5 caller 在 memory pillar: state.rs / kb.rs / conversation_logger / pty_event_worker / memory_scheduler"
      :agent-decision "stop 执行, 不硬推 drop. 报主会话, 记 D010"
      :main-claude-decision "选方案 B phased: 迁 memory 侧 5 caller, tasks 表保留给 pillar 二. 类比 TimelineStore 归 pillar 四 的模式 — 按 'ownership by usage' 原则, tasks 实际归 pillar 二 compute"
      :lisp-revised "v0.5.0 lisp 修订: tasks status 从 ✅ DROPPED 改为 ⚠ PARTIAL MIGRATION; memory-hook 迁出 board_tasks, tasks 表保留给 pillar 二"
      :executed-at "v0.5.0 B 方案 agent (a80620afcfcc98c5d)"
      :at "2026-04-20")

    (D009
      :source "Phase 6 agent (a1101c5e5020c65fa) 遵循 lisp 而非任务 prompt"
      :lisp-says "module system-support :: legacy-zone:"
      :tasks "✓ KEEP — legacy slot API 仍在使用 (memory_scheduler/autopilot/pty_event_worker 30+ 调用)"
      :inbox "⚠ DEPRECATE — 轻度使用 (autopilot/strategy_worker 仍写)"
      :events "❌ DROP-CANDIDATE (event_log 取代)"
      :credentials "❌ DROP-CANDIDATE (dead schema)"
      :task-prompt-said "Phase 6 drop 全 6 张 (含 tasks + inbox)"
      :agent-decision "保守只 drop 4 张 (narrations 2 + events + credentials), tasks + inbox 延后"
      :rationale "lisp 是真相, tasks/inbox 仍在活跃调用链, 贸然 drop 会编译失败"
      :next-step "指挥官接手后决定: (a) 迁移 tasks/inbox 活跃 caller 到新接口 → 后续 drop; (b) 保留 tasks/inbox 作 legacy 永久保存; (c) 其他策略"
      :status "approved-decided by agent, 留给指挥官 review"
      :at "2026-04-20 phase-6")

    (D010
      :source "v0.5.0 迁移 agent (主 Claude Opus 4.7) stop-and-report per 任务 '保守迁移' 规则"
      :task-prompt-said
        "memory-hook v0.5.0: tasks → board_tasks. 6 caller + 8 SlotStore 方法删 + tasks DROP."
        "active-callers-in-memory-pillar: state.rs::submit_task / handlers/knowledge/kb.rs / workers/local/conversation_logger.rs / workers/local/pty_event_worker.rs / handlers/knowledge/board.rs (已 board_tasks)"
      :ground-truth-scope-survey "grep 全仓后 tasks 相关 caller 实际分布:"
      :callers-within-memory-hook-scope-5
        ("state.rs::submit_task           — 入口, insert_task (1 site)"
         "handlers/knowledge/kb.rs:1726   — state::submit_task 调用 (1 site)"
         "handlers/knowledge/board.rs:637,659 — update_task (2 sites, 和 submit_task 配对)"
         "workers/local/conversation_logger.rs:370,375 — submit_task + update_task (2 sites)"
         "workers/local/pty_event_worker.rs:317-410 — get_tasks_by_status + update_task (2+ sites)")
      :callers-outside-memory-hook-scope-surprise-6
        ("handlers/compute/task.rs (500+ 行) — mission_task_submit/_query/_cancel/_ack/_track MCP 工具族的 handler;"
         "                                      使用 insert_task/update_task/get_task/get_tasks_by_status/get_all_tasks/ack_completed_tasks 共 6 方法 × 10+ call sites;"
         "                                      是外部 MCP client (Claude Code 主会话) 通用任务提交 API, 不是 memory-hook"
         "supervisor.rs:44,122,468 — requeue_running_tasks_for_slot (3 sites, slot 死亡后任务回收)"
         "handlers/compute/pty.rs:238 — requeue_running_tasks_for_slot (1 site, PTY 重启)"
         "context/context_pipeline.rs:1137 — ack_completed_tasks (1 site, Hook 源任务 ack)"
         "engine/intent_engine/memory_scheduler.rs — 除 dispatch_queued_submit_tasks/reap_stale_submit_tasks 外另有 update_task 5 sites (内部 FSM 推进)"
         "engine/learning_engine/extraction.rs:75,335 — get_tasks_by_status Running (2 sites, 学习引擎查当前 running)"
         "(小计: 10 文件 / 30+ call sites / 8 方法全部在用)")
      :mcp-tool-surface-impact
        "mission_task_submit (async/sync)"
        "mission_task_query (status/list/ack/track)"
        "mission_task_cancel"
        "4 个 legacy name alias (mission_submit/ask/status/cancel/task/task_ack/task_track)"
        "→ 全部走 tasks 表; lisp mcp-surface :: family-system 里未列, 但代码实存"
      :scope-discrepancy
        "任务 prompt 说 6 callers + 保守迁移. 实际是 10 文件 30+ sites, 含 MCP 工具族这种用户 API"
        "按 prompt 直接 drop tasks 表会: (a) mission_task_submit 编译失败 (b) supervisor/extraction 编译失败 (c) 整个任务 MCP API 消失"
        "D009 已明确 tasks 是 🔴 CORE, 30+ 调用, KEEP"
      :lisp-v0.5-stance "frozen lisp 把 tasks 写成 ✅ DROPPED v0.5.0 — 乐观态度先于代码"
      :agent-decision "stop-and-report. 不执行 migration, 不改 traits, 不改 state.rs, 不 drop tasks. 主会话需澄清:"
      :options-for-commander
        "(A) 真全面迁移: 迁 mission_task_submit MCP 工具族到 board_tasks (含 role 字段映射/status 迁移) + 迁 supervisor/extraction/pipeline. 工作量 = 原 prompt × 5x. 多 session 任务, 不是单 agent 能办"
        "(B) 分阶段迁移: v0.5.0 先只迁 memory-hook 5 callers, tasks 表保留给 mission_task_submit 族; 等 v0.5.1+ 再迁 MCP 工具. lisp v0.5.0 改为渐进式声明 (不立即 DROP tasks)"
        "(C) 架构澄清: mission_task_submit/_query/_cancel 是否应在 memory pillar? 从 MCP 工具族看, 它也许属 pillar 二/三, 不属 memory. lisp 需澄清归属"
        "(D) 放弃 v0.5.0 tasks drop, 只加 trigger_source 列预备; mission_task_submit 继续用 tasks, memory-hook 也继续用 tasks + 用 trigger_source 区分来源. 软过渡"
      :agent-recommendation "(B) 分阶段最稳. mission_task_submit 迁 board_tasks 需重设计 (role 字段→category 映射, 或引入 board_tasks.role 列)"
      :no-code-changes-made "未动 migration / trait / state.rs / 任何 caller; 仅记录此 D010 + execution log"
      :status "blocking — 等指挥官选 A/B/C/D"
      :at "2026-04-21 v0.5.0-attempt")

    (D003
      :lisp-said "Stage 2A.3 原计划 delete TimelineStore (基于 '它已 deprecated' 的假设)"
      :actually-found "TimelineStore 不是 deprecated; 它是 pillar 四 event-bus 的 projection 读接口 (event-bus-execution.lisp L170 明确声明 'db/pg/timeline.rs 重写: 每个 TimelineStore 方法 2-3 行 delegate 到 projection::*'); 被 ws/server.rs catch-up 和 handlers/comm/timeline.rs 的 5 MCP 工具 active 调用"
      :reason "phase-1.5 agent 对 traits.rs 13 trait 的分类把 TimelineStore 标 deprecated 是错的; TimelineStore 归 pillar 四 不归 memory"
      :decided "Stage 2A.3 动作修正: 保留 TimelineStore trait + 删 db/timeline.rs 冗余空壳 (551B re-export, 已被 shared:: 替代)"
      :scope-clarification "pg/timeline.rs / sqlite/timeline.rs / TimelineStore trait 全部归 pillar 四 event-bus 管, memory pillar 同构不动"
      :impact "memory pillar D002 的 13 code traits 重新计数: 9 primary 属 memory + DirectiveLayerStore TBD + 3 sub-traits (ToolCall/Event/Retrospective 合并 ConversationStore) + ...; 注意 TimelineStore 属 pillar 四 不计入 memory"
      :status "approved-decided"
      :at "2026-04-20 stage-2A.3"))

  ;; ─────────────────────────────────────────────────────────
  ;; decisions — 决策日志 (非 frozen lisp 改动, 施工过程的小决策)
  ;; ─────────────────────────────────────────────────────────
  (decisions
    (DC001
      :context "施工开工"
      :rationale "v0.4.23 frozen @ a282f87 后开此 execution lisp 作为并行 agent 共享内存层"
      :decided-by "指挥官 + Claude Opus 4.7"
      :at "2026-04-20"))

  ;; ─────────────────────────────────────────────────────────
  ;; completions — phase 完成清单
  ;; ─────────────────────────────────────────────────────────
  (completions
    (comp-001
      :phase "phase-1-scan"
      :agent "explore-agent (main session dispatched)"
      :summary "扫 in-scope 路径完成; 14 骨架文件 12 match 2 mismatch; 发现 22 wild files; trait count 9 vs 14 discrepancy"
      :blockers-raised ["D001" "D002"]
      :issues-raised ["I001" "I002" "I003"]
      :deliverable-location "file-scan-results 槽位 (此 execution lisp)"
      :at "2026-04-20")

    (comp-002
      :phase "phase-1.5-deep-trait-investigation"
      :agent "explore-agent (dispatched after I001+D001+D002)"
      :summary "精核 traits.rs 13 traits, 给出 10 项 trait 级对齐动作 (rename 1 + delete 1 + merge 5 + 新建 2 + 保留 N)"
      :resolved ["D001" "D002" "I003"]
      :at "2026-04-20")

    (comp-003
      :phase "phase-1.6-gen-migration-sqlite-investigation"
      :agent "explore-agent (dispatched for I004 I005 I006)"
      :summary "两套 gen_*.rs 都可删 (未被 mod.rs 导入); migration.rs 是 SQLite schema 脚本非 runner; sqlite/ 13 文件仍 active 为迁移工具, 分步清理"
      :resolved ["I005" "I006" "I007 info"]
      :refined ["I004"]
      :at "2026-04-20"
      :phase-2-ready true)

    (comp-004
      :phase "phase-2-stage-2A.1"
      :agent "general-purpose agent (adf12f667fb1b1875)"
      :summary "删除两套 gen_*.rs: db/gen_*.rs 根下 8 个 + db/gen/ 子目录 8 个 = 16 文件"
      :deleted "16 文件 / 8302 LOC / ~285KB"
      :verified-mod-rs "无 mod gen_* / 无 pub mod gen; 确认未导入"
      :cargo-build "通过 (Finished dev profile in 12.93s, 仅 pg/board.rs:852 unused_mut pre-existing warning)"
      :resolved ["I005"]
      :at "2026-04-20")

    (comp-005
      :phase "phase-2-stage-2A.2"
      :agent "general-purpose agent (a7c3bc9b9e93c7bd5)"
      :summary "KnowledgeStore → KbStore rename (代码对齐 lisp)"
      :files-modified 3
      :cargo-build "workspace 通过"
      :at "2026-04-20")

    (comp-006
      :phase "phase-2-stage-2A.3"
      :agent "主 Claude (直接执行, 基于 general-purpose agent a108680e474c84b1e 调研)"
      :summary "TimelineStore 归属修正 + 删 db/timeline.rs 空壳"
      :key-finding "D003: TimelineStore 不是 deprecated 而是 pillar 四 projection 读接口, 归 pillar 四"
      :changes
        ("删除 db/timeline.rs (551B re-export 冗余)"
         "删除 db/mod.rs:46 sqlite-gated 'pub(crate) mod timeline;'")
      :untouched "TimelineStore trait / pg/timeline.rs / sqlite/timeline.rs (归 pillar 四)"
      :cargo-build "通过"
      :at "2026-04-20")

    (comp-007 :phase "2B.1" :summary "InfraStore trait 空壳" :cargo "通过" :at "2026-04-20")
    (comp-008 :phase "2B.2" :agent "a29e205bbc09f4a16" :summary "DirectiveLayerStore 17 方法完整 PG impl (types+db+pg 3 新文件)" :cargo "通过" :at "2026-04-20")
    (comp-009 :phase "2C.1" :agent "a1ceaa5a700e618e1" :summary "SkillStore 25 方法合并进 ProjectStore (+8=33 total); pg/project.rs 的 8 方法搬进 pg/skill.rs 单一 impl; 补建 db/project.rs (18L re-export + D001 达成)" :cargo-workspace "通过" :rust-analyzer-note "E0119/E0046 IDE 误报, cargo feature 组合不同导致" :at "2026-04-20")
    (comp-010 :phase "2C.2+2C.3+2C.4" :agent "aaeb025f65c3e3bb0" :summary "ToolCallStore(19)+EventStore(7)+RetrospectiveStore(15) 合并进 ConversationStore; 删 pg/{tool_call,event,retrospective}.rs + sqlite/同名 6 文件" :cargo-workspace "通过" :at "2026-04-20")
    (comp-011 :phase "2C.5" :agent "a2f09b18427fb6ad3" :summary "VisionStore 10 方法合并进 ObservabilityStore; 补建 db/observability.rs" :cargo "通过" :at "2026-04-20")
    (comp-012 :phase "2D" :agent "af46ad1392fe21100" :summary "InfraStore 填 24 方法" :cargo "通过" :at "2026-04-20")
    (comp-013 :phase "2E" :agent "af7519bb19abb5f42" :summary "SQLite 生态大扫除 ~14018 LOC" :cargo "通过" :at "2026-04-20")
    (comp-014 :phase "phase-4+5 audit" :agent "ab3a924be68435f5a"
      :summary "lisp ↔ code 双向校验: 9/9 trait + 60/60 表 + 51/51 cross-ref 全通过; 5 D-series non-critical doc drift"
      :at "2026-04-20")
    (comp-015 :phase "phase-6" :agent "a1101c5e5020c65fa" :summary "Drop 4 legacy 表 + zombie cleanup" :cargo "通过" :at "2026-04-20")
    (comp-016 :phase "v0.5.0-scout" :agent "a6e8e73cafad2d6e5"
      :summary "v0.5.0 memory-hook 迁移前调研 — 发现 tasks 表 30+ caller 中 25 在 pillar 二"
      :action "stop 执行, 记 D010, 等主会话决策"
      :cargo "未 build (未改代码)"
      :at "2026-04-20")
    (comp-017 :phase "v0.5.0-phased-B" :agent "a80620afcfcc98c5d"
      :summary "D010 决策后执行: memory-hook 5 caller 迁 board_tasks, tasks 表保留"
      :files
        ("migrations/20260421100000_add_board_tasks_trigger_source.sql (ALTER + INDEX, 不 DROP)"
         "types/board.rs: BoardTask 加 trigger_source 字段"
         "traits.rs: BoardStore 加 list_board_tasks_by_trigger"
         "pg/board.rs: impl + insert_board_task + PgBoardTaskRow 更新")
      :callers-migrated
        ("state::submit_task → insert_board_task (trigger_source='memory_hook', category=role)"
         "handlers/knowledge/kb.rs:1726 (自然跟进)"
         "workers/local/conversation_logger.rs:370-383 update_task → update_board_task"
         "workers/local/pty_event_worker.rs handle_submit_task_closure 重写用 board_tasks poll"
         "engine/intent_engine/memory_scheduler.rs: dispatch + reap 改 board + claim_board_task")
      :verification "grep memory-pillar 侧 insert_task/get_tasks_by_status/requeue 0 match"
      :cargo "--workspace 0 error; cargo test -p missiond-core 272/272 passed"
      :at "2026-04-20"))

  ;; ─────────────────────────────────────────────────────────
  ;; issues — 阻塞 / 未决问题
  ;; ─────────────────────────────────────────────────────────
  (issues
    (I001
      :severity "medium"
      :desc "22 个 'wild files' 未列在 lisp 骨架 file-to-module-mapping, 包括: audit.rs / beacon.rs / shared.rs / error.rs / conversation_query.rs / message_feed.rs / router_chat.rs / timeline.rs(deprecated) / narration.rs / translation.rs / watermark.rs / dynamic_slot.rs / executor.rs / mod.rs / migration.rs + 10 个 gen_*.rs (forge 冲压产物)"
      :resolution-path "phase-1 完成 deliverable 包含补分类; 每文件归到对应 module 或标 '辅助/子功能/codegen'"
      :not-blocker "属于补全动作, 不阻断施工"
      :at "2026-04-20 phase-1 scan")

    (I002
      :severity "low"
      :desc "timeline.rs 已 deprecated (v1.3.0 event_log 取代), 但文件仍在代码里仅做 re-export"
      :lisp-standing "lisp 已在 pillar-interfaces / retention-policy 多处标明 timeline SSOT 迁 event_log; 但 timeline.rs 本身的 drop 未入 phase-6 清单"
      :resolution "phase-6 drop migration 时一并清 (或单独 track)"
      :at "2026-04-20 phase-1 scan")

    (I003
      :severity "info"
      :desc "migrations/ 实际 22 个 .sql 文件, lisp 称 60 表. agent 口径 '61 张实际' 可能把 drop_system_timeline 也算了. 需 phase-4 精确核对"
      :resolved "phase-1.5 agent 确认 60 表现存 + 1 已 drop (system_timeline) = 61 migrations 定义; 对齐 lisp ✓"
      :at "2026-04-20 phase-1 scan")

    (I004
      :severity "high"
      :desc "db/sqlite/ 子目录存在 13 个文件 (deprecated per lisp). 需清理"
      :refined-at-phase-1.6 "13 文件 (非 15), mod.rs 无 deprecated 标记但注释说 'Wraps MissionDB via DbExecutor'. 仍 active 用于 SQLite → PG 数据迁移 (通过 pg/migrate_from_sqlite.rs)"
      :still-active-reason "cfg(feature = 'sqlite') 编译门控; migrate_from_sqlite 仍依赖"
      :resolution-path "(分步) phase-2 里: 验证迁移完成 → 删 cfg(feature='sqlite') 代码 → 最后删整个 sqlite/ 目录"
      :at "2026-04-20 phase-1.5 ls 发现, phase-1.6 精查")

    (I005
      :severity "high"
      :desc "gen_*.rs 两套: db/ 根下 8 个 + db/gen/ 子目录 8 个"
      :resolved-at-phase-1.6
        :两套关系 "完全重复 (文件名对应, 内容相同). 都标 // GENERATED BY FORGE - DO NOT EDIT, Source: intent-db.lisp"
        :mtime "根目录 2026-04-19 (新), db/gen/ 2026-04-09 (旧缓存)"
        :active-status "⚠ 两套都未被 mod.rs 导入 — 当前均不活跃, 被 traits.rs + pg/ 架构取代"
        :action "phase-2 删除两套共 16 个 gen_*.rs 文件 (约 250KB)"
      :at "2026-04-20 phase-1.5 ls → phase-1.6 resolved")

    (I006
      :severity "medium"
      :desc "migration.rs (73KB) 在 db/ 根下, 性质未知"
      :resolved-at-phase-1.6
        :实际是 "SQLite 表创建 SCHEMA 脚本 (const SCHEMA + init() 函数, 1675 行)"
        :非 "migration runner (PG 用 sqlx::migrate! + migrations/*.sql)"
        :依赖方 "仅 SQLite backend 启动时调用"
        :action "phase-2 里: 标 [deprecated]; 跟 sqlite/ 清理同步删除"
      :at "2026-04-20 phase-1.5 ls → phase-1.6 resolved")

    (I007
      :severity "info"
      :desc "traits.rs 架构确认"
      :findings
        ("traits.rs 行首注释说 '12 domain-specific async traits' (实际 13, 行首注释有 1 数字误)"
         "最后 20 行定义 super-trait MissionStore 聚合所有 13 个 domain traits + init() 方法"
         "SQLite 和 PG backend 都实现 MissionStore (traits.rs 作为统一入口设计正确)")
      :施工-note "MissionStore super-trait 架构和 lisp cross-cutting :: capability db-trait-abstraction 一致; v0.4.20 已修正 stores 数字 9 → 实际 13 (代码向 lisp 对齐后 9 primary + sub-traits 合并)"
      :at "2026-04-20 phase-1.6"))

  ;; ─────────────────────────────────────────────────────────
  ;; phase-1 产出: file-to-module-mapping 扫描结果
  ;; 扫完后补填; 完成后主 Claude 审核 → 记 completion → 进 phase-2
  ;; ─────────────────────────────────────────────────────────
  (file-scan-results
    :status "phase-1 scan 完成 (agent explore-1 于 2026-04-20)"
    :target-sync "intent-memory.lisp :: target-code-layout :: file-to-module-mapping"

    (骨架-14-match-summary
      (match  12 "ast.rs / board.rs / conversation.rs / gemini_log.rs / incident.rs / knowledge.rs / question.rs / skill.rs / slot.rs / task.rs / backfill.rs / traits.rs")
      (mismatch 2 "db/project.rs + db/observability.rs 不存在 (见 D001)")
      :mismatch-resolution "待 D001 决策")

    (extras-unaccounted-22
      :note "lisp 骨架未列, 本次扫描发现的 in-scope 文件; 需补入 mapping"

      (helper-support
        (audit.rs       :serves "conversation-logs" :trait "ToolCallStore (混合)" :note "tool call 审计")
        (beacon.rs      :serves "kb-manager"        :note "beacon CRUD (kb-manager 子功能)")
        (shared.rs      :serves "all modules"       :note "Row struct + enum shared types")
        (error.rs       :serves "all modules"       :note "DbError type"))

      (query-view-helpers
        (conversation_query.rs :serves "conversation-logs" :note "conversation FTS query builder")
        (message_feed.rs       :serves "conversation-logs" :note "message stream view")
        (router_chat.rs        :serves "system-support"    :note "router chat state (配套 router_chat_archive)"))

      (legacy-infra
        (timeline.rs    :status "DEPRECATED (v1.3.0 后仅 re-export shared types)"
                        :owned-by "system-support legacy (候选 drop)")
        (narration.rs   :status "LEGACY (narration 表 pending-drop-v0.4.12)"
                        :owned-by "conversation-logs pending-drop")
        (translation.rs :serves "conversation-logs" :note "message_translations 表支持")
        (watermark.rs   :serves "system-support"    :note "消息 watermark tracking")
        (dynamic_slot.rs :serves "slot-support"     :note "dynamic_slot state 管理细节")
        (executor.rs    :serves "slot-support (间接)" :note "executor lifecycle"))

      (infra-module
        (mod.rs         :serves "all modules"  :note "db/ 模块定义")
        (migration.rs   :serves "all modules"  :note "migrations runner infra"))

      (forge-generated-10
        :note "forge 冲压产物, 当前 gitignored. 施工时按对应 module 分组"
        (gen_audit.rs       :module "conversation-logs (audit)")
        (gen_board.rs       :module "board")
        (gen_compute.rs     :module "slot-support")
        (gen_conversation.rs :module "conversation-logs")
        (gen_knowledge.rs   :module "kb-manager")
        (gen_misc.rs        :module "system-support")
        (gen_pipeline.rs    :module "?? (需细察)")
        (gen_skill.rs       :module "project-management")
        :missing-2 "agent 列 8 but 上面 claim 10; 需 phase-2 精确核对"))

    (pg-impl-alignment
      :status "pg/*.rs 13 文件对应 14 trait impl"
      :files "pg/{board,conversation,event,knowledge,message,observability,project,retrospective,skill,slot,timeline,tool_call,vision}.rs"
      :note "observability 只在 pg/ 有 (见 D001); vision pg impl 存在但 trait 未在 lisp 9 list")

    (trait-count-discrepancy
      :lisp-says 9
      :agent-reports 14
      :extras-guess "KnowledgeStore(vs KbStore) / SkillStore / ToolCallStore / RetrospectiveStore / VisionStore / EventStore — 需 phase-2 精确核对"
      :see D002))

  ;; ─────────────────────────────────────────────────────────
  ;; phase-2+ 产出预留 (施工过程中填)
  ;; ─────────────────────────────────────────────────────────
  (module-impl-checklists
    :status "pending phase-2")

  (directive-layer-implementation
    :status "pending phase-3"
    :required-trait "DirectiveLayerStore (15 方法)"
    :required-files ["db/directive.rs" "db/pg/directive.rs" "types/directive.rs"])

  (binds-to-verification
    :status "pending phase-4"
    :target "96 个 writer/reader 的 :cross-ref 指向真实代码函数")

  (isomorphism-audit
    :status "pending phase-5"
    :bidirectional "lisp → code + code → lisp")

  (drop-migration-plan
    :status "pending phase-6"
    :candidates ["message_narrations" "narration_cursors" "tasks" "inbox" "events" "credentials"]
    :note "lisp 已标 pending-drop; migration 待写")

  ;; ─────────────────────────────────────────────────────────
  ;; Stage 2F 产出: 代码 → module 终极映射 (Stage 2E 后)
  ;; 体现 lisp target-code-layout :: file-to-module-mapping 实际落地
  ;; ─────────────────────────────────────────────────────────
  (file-to-module-mapping-complete
    (desc "Stage 2A-2E 后代码层最终映射 — memory pillar 9 module × 代码文件")
    :status "completed-at-stage-2F"
    :at "2026-04-20"

    (db-root-layer
      (traits.rs            :serves "all 9 modules" :purpose "MissionStore super-trait 聚合 + 8 primary trait 定义 (ProjectStore / BoardStore / KbStore / ConversationStore / MessageStore / ObservabilityStore / SlotStore / InfraStore / DirectiveLayerStore + 外部 TimelineStore 归 pillar 四)")
      (shared.rs            :serves "all modules"   :purpose "通用 Row struct + enum + 工具类型 (TimelineRow/AstNodeRow/BackfillPhaseStatus)")
      (error.rs             :serves "all modules"   :purpose "DbError + DbResult (Stage 2E 删 Sqlite 变体)")
      (mod.rs               :serves "all modules"   :purpose "db 模块定义 + 工具 fn (derive_conversation_type / extract_parent_session_id)")
      (project.rs           :serves "project-management" :purpose "D001 补建, re-export ProjectConfig + 架构指针")
      (observability.rs     :serves "llm-support + system-support + conversation-logs" :purpose "D001 补建, re-export BackfillPhaseStatus")
      (directive.rs         :serves "directive-layer" :purpose "Stage 2B.2 新建, row struct mapping")
      (conversation_query.rs :serves "conversation-logs" :purpose "conversation FTS query builder helper"))

    (db-pg-layer
      (mod.rs               :serves "all" :purpose "PG 模块定义 + PgMissionStore struct")
      (project.rs           :serves "project-management" :purpose "helper fn 模块 (impl 在 skill.rs)")
      (skill.rs             :serves "project-management" :purpose "承载 impl ProjectStore (33 方法: projects 8 + skill_* 25)")
      (board.rs             :serves "board"              :purpose "impl BoardStore (41 方法)")
      (knowledge.rs         :serves "kb-manager"         :purpose "impl KbStore (56 方法)")
      (conversation.rs      :serves "conversation-logs"  :purpose "impl ConversationStore (~114 方法合并 ToolCall/Event/Retrospective)")
      (message.rs           :serves "conversation-logs"  :purpose "impl MessageStore (15 方法)")
      (observability.rs     :serves "llm/system/conversation" :purpose "impl ObservabilityStore (58 方法, Stage 2D 拆出 watermarks/backfill)")
      (slot.rs              :serves "slot-support + system-support" :purpose "impl SlotStore (38 方法, Stage 2D 拆出 daemon_state)")
      (infra.rs             :serves "system-support"     :purpose "impl InfraStore (24 方法, Stage 2D 新填充)")
      (directive.rs         :serves "directive-layer"    :purpose "impl DirectiveLayerStore (17 方法, Stage 2B.2 新建)")
      (timeline.rs          :serves "pillar 四 (non-memory)" :purpose "impl TimelineStore projection delegate — 归 pillar 四 event-bus, memory 同构不动")
      (migrate_from_sqlite.rs :serves "legacy tool"      :purpose "DEPRECATED, feature-gated 'all(sqlite, postgres)' 永不编译, 保留作历史迁移工具"))

    (types-layer
      ("types/directive.rs" :serves "directive-layer" :purpose "Stage 2B.2 新建: Directive/Plan/Workflow struct + DirectiveStatus/PlanStatus enum")
      ("types/其他"          :serves "按模块"          :purpose "Row struct + FSM enum, 细节不展开"))

    (mcp-handlers-layer
      :location "crates/missiond-daemon/src/handlers/"
      :scope "MCP tool handlers — memory pillar mcp-surface 的实现"
      :note "按 lisp pillar-interfaces mcp-surface 的 8 tool-families 组织, 具体每文件归属留 phase-4 binds-to 验证补")

    (mcp-tools-layer
      :location "crates/missiond-mcp/src/tools/"
      :scope "MCP tool 定义 (client-facing schema)"
      :note "按 lisp mcp-surface family 分目录: knowledge/ comm/ sysinfra/ compute/ 等")

    (ws-bridge
      :file "crates/missiond-daemon/src/bus/ws_bridge.rs"
      :serves "frontend-surface"
      :note "memory 的 5 streams (conversation / board / project / timeline / llm-trace) 由此桥接")

    (eliminated-wild-files
      :note "以下 Stage 2A-2E 过程中消除 (删除 / 合并 / rename), 不再是 wild"
      (gen_*.rs         :phase "2A.1 删 16 文件 (两套均未引用)")
      (KnowledgeStore   :phase "2A.2 rename → KbStore")
      (db/timeline.rs   :phase "2A.3 删 (冗余空壳, 归 pillar 四)")
      (SkillStore       :phase "2C.1 合并进 ProjectStore")
      (ToolCallStore / EventStore / RetrospectiveStore :phase "2C.2-2C.4 合并进 ConversationStore")
      (VisionStore      :phase "2C.5 合并进 ObservabilityStore")
      (db/backfill.rs /db/watermark.rs :phase "2D 方法搬 InfraStore, 原文件 2E 删")
      (sqlite/ 整目录   :phase "2E 删除 10 文件")
      (db/ sqlite-gated 21 文件 :phase "2E 删除"))

    (final-code-structure-summary
      :db-root       "8 文件 (traits / shared / error / mod / project / observability / directive / conversation_query)"
      :db-pg         "13 文件 (10 business impl + timeline 归 pillar 四 + migrate_from_sqlite deprecated + mod)"
      :types         "按 module 分"
      :mcp-handlers  "按 tool family 分目录 (handlers/)"
      :mcp-tools     "按 tool family 分目录 (tools/)"
      :ws-bridge     "单文件聚合 5 streams")))
